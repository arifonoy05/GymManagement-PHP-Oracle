<?php

	require_once('../model/db.php');

	if(isset($_REQUEST['update'])){

		$uid         = $_REQUEST['id'];
		$name 		 = $_REQUEST['name'];
		$contact 	 = $_REQUEST['contact'];
		$joindate	 = $_REQUEST['joindate'];
        $trainer 	 = $_REQUEST['trainer'];
        
        echo $uid;
        
            // $sql = "update gym_member set member_name='{$name}', contact='{$contact}', trainer_id='{$trainer}' where member_id={$uid}";
            $sql = "begin member_upd ('$uid','{$name}','{$contact}','{$trainer}'); end;";
            $stmt = oci_parse($con, $sql);
            oci_execute($stmt);

			if($stmt){
				header("location: ../views/members.php");
			}else{
				header("location: ../views/updateMember.php?error=sql_error");
			}

		}
		else{
			header("location: ../views/updateMember.php?error=null_found");
		}
?>