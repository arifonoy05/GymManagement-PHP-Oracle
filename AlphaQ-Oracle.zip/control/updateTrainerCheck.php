<?php

	require_once('../model/db.php');

	if(isset($_REQUEST['update'])){

		$uid         = $_REQUEST['id'];
		$name 		 = $_REQUEST['name'];
		$contact 	 = $_REQUEST['contact'];
		$hiredate	 = $_REQUEST['hiredate'];
        $salary 	 = $_REQUEST['salary'];
        
        echo $uid;
        
            // $sql = "update gym_trainer set trainer_name='{$name}', contact='{$contact}', salary='{$salary}' where trainer_id={$uid}";
            $sql = "begin trainer_upd ('$uid','{$name}','{$contact}','{$salary}'); end;";
            $stmt = oci_parse($con, $sql);
            oci_execute($stmt);

			if($stmt){
				header("location: ../views/trainers.php");
			}else{
				header("location: ../views/updateTrainer.php?error=sql_error");
			}

		}
		else{
			header("location: ../views/updateTrainer.php?error=null_found");
		}
?>