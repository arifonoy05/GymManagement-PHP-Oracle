<?php
    require_once('../model/db.php');

	$uid = "";
	if(isset($_GET['id'])){
		$uid= trim($_GET['id']);
		$sql = "delete from gym_member where member_id={$uid}";
		$conn = getConnection();
		$stmt = oci_parse($conn, $sql);
        oci_execute($stmt);
        
        header('location: ../views/members.php');
	}

?>