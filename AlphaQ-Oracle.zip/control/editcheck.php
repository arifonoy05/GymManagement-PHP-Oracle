<?php

	require_once('../model/db.php');

	if(isset($_REQUEST['update'])){
		
		// $name 			= $_POST['NAME'];
		$username 		= $_REQUEST['username'];
		$password 		= $_REQUEST['password'];
		$id				= $_REQUEST['id'];
		// $email 			= $_POST['EMAIL'];

		if($username != "" && $password != ""){
			$conn = getConnection();
			$sql = "Update users set username='{$username}', password='{$password}' where id={$id}";

			//echo $sql;
			$stmt = oci_parse($conn, $sql);
			oci_execute($stmt);

			if($stmt){
				header("location: ../views/home.php");
			}else{
				header("location: ../views/edit.php?error=sql_error");
			}

		}
		else{
			header("location: ../views/edit.php?error=null_found");
		}
	}else{
		header("location: ../views/edit.php?error=invalid_request");
	}
?>