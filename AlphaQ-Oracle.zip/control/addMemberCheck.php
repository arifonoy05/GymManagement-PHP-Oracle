<?php
    session_start();
    require_once('../model/db.php');        

if (isset($_REQUEST['submit'])) {
    $name       = trim($_REQUEST['name']);
    $contact    = trim($_REQUEST['contact']);
    $joindate   = trim($_REQUEST['joindate']);
    $trainerID  = trim($_REQUEST['trainer']);

    $con = getConnection();
        // $sql = "insert into gym_members values (id_seq.nextval, '{$name}','{$username}','{$password}','{$email}')";
        $sql = "begin member_reg(member_seq.nextval,'{$name}','{$contact}','{$joindare}','{$trainerID}'); end;";
        $stmt = oci_parse($con, $sql);
        $result = oci_execute($stmt);
        if($result){
            // DATA INSERTION SUCCESSFULL, INCLUDING AUTO_INCREMENT_ID
            header('location: ../views/home.php');
        }
        else{
            echo "registration failed";
        }
} 
else {
    print "data not inserted";
    // header('location: ../views/register.php');
}
?>
<!-- DON NOT EDIT -->