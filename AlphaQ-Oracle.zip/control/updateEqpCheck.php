<?php

	require_once('../model/db.php');

	if(isset($_REQUEST['update'])){

		$uid         = $_REQUEST['id'];
		$name 		 = $_REQUEST['name'];
		$price 	 = $_REQUEST['price'];
		$purchase	 = $_REQUEST['purchase'];
        $gid 	 = $_REQUEST['gid'];
        
        echo $uid;
        
            // $sql = "update gym_trainer set trainer_name='{$name}', contact='{$contact}', salary='{$salary}' where trainer_id={$uid}";
            $sql = "begin eqp_upd ('$uid','{$name}','{$price}'); end;";
            $stmt = oci_parse($con, $sql);
            oci_execute($stmt);

			if($stmt){
				header("location: ../views/equipments.php");
			}else{
				header("location: ../views/updateEqp.php?error=sql_error");
			}

		}
		else{
			header("location: ../views/updateEqp.php?error=null_found");
		}
?>