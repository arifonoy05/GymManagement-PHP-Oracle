<?php
    session_start();
    require_once('../model/db.php');        

if (isset($_REQUEST['submit'])) {
    $name       = trim($_REQUEST['name']);
    $contact    = trim($_REQUEST['contact']);
    $hiredate   = trim($_REQUEST['hiredate']);
    $salary     = trim($_REQUEST['salary']);

    $con = getConnection();
        // $sql = "insert into users values (id_seq.nextval, '{$name}','{$username}','{$password}','{$email}')";
        $sql = "begin trainer_reg(trainer_seq.nextval,'{$name}','{$contact}','{$hiredare}','{$salary}', 1); end;";
        $stmt = oci_parse($con, $sql);
        $result = oci_execute($stmt);
        if($result){
            // DATA INSERTION SUCCESSFULL, INCLUDING AUTO_INCREMENT_ID
            header('location: ../views/home.php');
        }
        else{
            echo "registration failed";
        }
} 
else {
    print "data not inserted";
    // header('location: ../views/register.php');
}
?>
<!-- DON NOT EDIT -->