<?php
	session_start();
	include('../model/db.php');

	if(isset($_REQUEST['submit']))
	{

		$username = trim($_REQUEST['username']);
		$password = trim($_REQUEST['password']);
		
		if($username == ""){
			echo "invalid or empty name..<br>";
		}else if($password == ""){
			echo "invalid or empty password..";
		}else{
			$conn = getConnection();
			$sql = "select * from gym_admin where username='{$username}' and password='{$password}'";

			$stmt = oci_parse($conn, $sql);
			$result = oci_execute($stmt);
			$row = oci_fetch_assoc($stmt);
	
			if($row['USERNAME']== $username && $row['PASSWORD'] == $password){

				$_SESSION['name'] = $username;
				header('location: ../views/home.php');
			}else{
				header('location: ../views/login.php');
				print_r($row);
			}
		}

	}else{
		header('location: ../views/login.php');
	}
?>
