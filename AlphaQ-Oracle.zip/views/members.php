<?php
	session_start();
	include_once('../model/db.php'); 
?>
		<!DOCTYPE html>
		<html>
		<head>
            <title>Members List</title>
            <link rel="stylesheet" href="../css/bootstrap.min.css">
		</head>
		<body>
            <nav>
                <div class="container">
                    <div class="row">
						<a href="profile.php">Profile</a>
						<a href="../control/logout.php">Logout</a>
					</div>
                </div>
            </nav>
            <div class="container">
                <div class="content">
                    <?=$_SESSION['name']?>
                    <br>
                    <a href="home.php">Back</a>
                    
                    <h3>Members List </h3>		
                    <table border="1">
                        <tr>
                            <td>ID</td>
                            <td>NAME</td>
                            <td>CONTACT</td>
                            <!-- <td>JOINING DATE</td> -->
                            <td>TRAINER</td>
                            <td>ACTION</td>
                        </tr>
                    <?php
                        $conn = getConnection();
                        $sql = "select * from gym_member";
                        $stmt = oci_parse($conn, $sql);
                        oci_execute($stmt);

                        while($row = oci_fetch_assoc($stmt)){
                            echo "	<tr>
                                        <td>".$row['MEMBER_ID']."</td>
                                        <td>".$row['MEMBER_NAME']."</td>
                                        <td>".$row['CONTACT']."</td>";?>
                                        <!-- <td>".$row['JOIN_DATE']."</td> -->
                            <?php echo "<td>".$row['TRAINER_ID']."</td>
                                        <td>
                                            <a href='../views/updateMember.php?id=".$row['MEMBER_ID']."'>Edit</a> | 
                                            <a href='../control/deleteMember.php?id=".$row['MEMBER_ID']."'>Delete</a>
                                        </td>
                                    </tr>";
                        }
                    ?>
                    </table>
                </div>
            </div>
		</body>
		</html>		