<?php
	require_once('../model/db.php');

	if(isset($_GET['error'])){
		echo "error received";
		echo '<br>';
		if($_GET['error'] == 'null_found'){
			echo "Invalid username or password inputed!!";
		}
	}

	$uid = "";
	if(isset($_GET['id'])){
		$uid= trim($_GET['id']);
		$sql = "select * from gym_equipment where eqp_id={$uid}";
		$conn = getConnection();
		$stmt = oci_parse($conn, $sql);
		oci_execute($stmt);
		$row = oci_fetch_assoc($stmt);
	}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Equipment</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
</head>
<body>
    <nav>
        <div class="container">
            <div class="row">
				<a href="profile.php">Profile</a>
				<a href="../control/logout.php">Logout</a>
			</div>
        </div>
    </nav>
    <div class="container">
        <div class="content">
            <h2>Update Equipment Details</h2>
            <a href="trainers.php">Back</a>

            <form method="post" action="../control/updateEqpCheck.php">
                <table>
                    <td><input type="text" name="id" id="id" value="<?=$row['EQP_ID']?>" hidden></td>
                    <tr>
                        <td>Name</td>
                        <td><input type="text" name="name" id="name" value="<?=$row['EQP_NAME']?>" required></td>
                    </tr>
                    <tr>
                        <td>Price</td>
                        <td><input type="text" name="price" id="price" value="<?=$row['EQP_PRICE']?>" required></td>
                    </tr>
                    <tr>
                        <td>Purchase date</td>
                        <td><input type="date" name="purchase" id="purchase" value="<?=$row['HIRE_DATE']?>" required></td>
                    </tr>
                    <tr>
                        <td><input type="number" name="gid" id="gid" value="<?=$row['GYM_ID']?>" hidden></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type="submit" name="update" value="Update"></td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
</body>
</html>