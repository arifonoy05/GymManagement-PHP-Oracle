<?php
    session_start();
    require_once('../model/db.php');

    $sql = "select * from gym_trainer";
    $stmt = oci_parse($con, $sql);
    oci_execute($stmt);
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Register New Member</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
</head>
<body>
    <nav>
        <div class="container">
            <div class="row">
				<a href="profile.php">Profile</a>
				<a href="../control/logout.php">Logout</a>
			</div>
        </div>
    </nav>
    <div class="container">
            <div class="content">
                <?=$_SESSION['name']?>
                <br>
                <a href="home.php">Back</a>
                <h2>Register New Member</h2>
                <form method="post" action="../control/addMemberCheck.php">
                    <table>
                        <tr>
                            <td>Name</td>
                            <td><input type="text" name="name" id="name" required></td>
                        </tr>
                        <tr>
                            <td>Contact</td>
                            <td><input type="text" name="contact" id="contact" required></td>
                        </tr>
                        <tr>
                            <td>Joining date</td>
                            <td><input type="date" name="joindate" id="joindate" required></td>
                        </tr>
                        <tr>
                            <td>Trainer</td>
                            <td>
                                <select name="trainer">
                                    <?php
                                        while($row = oci_fetch_assoc($stmt)){
                                            echo "<option value=".$row['TRAINER_ID']." >".$row['TRAINER_NAME']."</option>";
                                        }
                                    ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td><input type="submit" name="submit" value="Register"></td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>
</body>
</html>