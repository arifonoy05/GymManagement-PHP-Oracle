<?php
	session_start();
	include_once('../model/db.php'); 
?>
		<!DOCTYPE html>
		<html>
		<head>
            <title>Trainers List</title>
            <link rel="stylesheet" href="../css/bootstrap.min.css">
		</head>
		<body>
            <nav>
                <div class="container">
                    <div class="row">
						<a href="profile.php">Profile</a>
						<a href="../control/logout.php">Logout</a>
					</div>
                </div>
            </nav>
            <div class="container">
                <div class="content">
                    <?=$_SESSION['name']?>
                    <br>
                    <a href="home.php">Back</a>
                    
                    <h3>Trainer List </h3>		
                    <table border="1">
                        <tr>
                            <td>ID</td>
                            <td>NAME</td>
                            <td>CONTACT</td>
                            <!-- <td>HIREDATE</td> -->
                            <td>SALARY</td>
                            <td>ACTION</td>
                        </tr>
                    <?php
                        $conn = getConnection();
                        $sql = "select * from gym_trainer";
                        $stmt = oci_parse($conn, $sql);
                        oci_execute($stmt);

                        while($row = oci_fetch_assoc($stmt)){
                            echo "	<tr>
                                        <td>".$row['TRAINER_ID']."</td>
                                        <td>".$row['TRAINER_NAME']."</td>
                                        <td>".$row['CONTACT']."</td>";?>
                                        <!-- <td>".$row['HIRE_DATE']."</td> -->
                            <?php echo "<td>".$row['SALARY']."</td>
                                        <td>
                                            <a href='../views/updateTrainer.php?id=".$row['TRAINER_ID']."'>Edit</a> | 
                                            <a href='../control/deleteTrainer.php?id=".$row['TRAINER_ID']."'>Delete</a>
                                        </td>
                                    </tr>";
                        }
                    ?>
                    </table>
                </div>
            </div>
		</body>
		</html>		