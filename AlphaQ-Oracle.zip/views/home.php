<?php
	session_start();
	include_once('../model/db.php'); 
?>
	<!DOCTYPE html>
	<html>
		<head>
			<title>Home Page</title>
			<link rel="stylesheet" href="../css/bootstrap.min.css">
		</head>
		<body>
			<nav>
				<div class="container">
					<div class="row">
						<a href="profile.php">Profile</a>
						<a href="../control/logout.php">Logout</a>
					</div>
				</div>
				<section class="content">
					<div class="container">
						<div class="row">
							<div class="col-md-4">
								<a href="trainers.php">List of Trainers</a>
							</div>
							<div class="col-md-4">
								<a href="members.php">List of Members</a>
							</div>
							<div class="col-md-4">
								<a href="equipments.php">List of Equipments</a>
							</div>
						</div>
						<div class="row">
							<div class="col-md-4">
								<a href="addTrainer.php">Add New Trainer</a>
							</div>
							<div class="col-md-4">
								<a href="addMember.php">Add New Member</a>
							</div>
							<div class="col-md-4">
								<a href="addEquipment.php">Add New Equipment</a>
							</div>
						</div>
					</div>
				</section>
			</nav>
		</body>
		</html>		
