<?php
	session_start();
	include_once('../model/db.php'); 
?>
		<!DOCTYPE html>
		<html>
		<head>
            <title>Equipments List</title>
            <link rel="stylesheet" href="../css/bootstrap.min.css">
		</head>
		<body>
            <nav>
                <div class="container">
                    <div class="row">
						<a href="profile.php">Profile</a>
						<a href="../control/logout.php">Logout</a>
					</div>
                </div>
            </nav>
            <div class="container">
                <div class="content">
                    <?=$_SESSION['name']?>
                    <br>
                    <a href="home.php">Back</a>
                    
                    <h3>Equipments List </h3>		
                    <table border="1">
                        <tr>
                            <td>ID</td>
                            <td>NAME</td>
                            <td>PRICE</td>
                            <!-- <td>PURCHASEDATE</td> -->
                            <td>GYM ID</td>
                            <td>ACTION</td>
                        </tr>
                    <?php
                        $conn = getConnection();
                        $sql = "select * from gym_equipment";
                        $stmt = oci_parse($conn, $sql);
                        oci_execute($stmt);

                        while($row = oci_fetch_assoc($stmt)){
                            echo "	<tr>
                                        <td>".$row['EQP_ID']."</td>
                                        <td>".$row['EQP_NAME']."</td>
                                        <td>".$row['EQP_PRICE']."</td>";?>
                                        <!-- <td>".$row['HIRE_DATE']."</td> -->
                            <?php echo "<td>".$row['GYM_ID']."</td>
                                        <td>
                                            <a href='../views/updateEqp.php?id=".$row['EQP_ID']."'>Edit</a> | 
                                            <a href='../control/deleteEquipment.php?id=".$row['EQP_ID']."'>Delete</a>
                                        </td>
                                    </tr>";
                        }
                    ?>
                    </table>
                </div>
            </div>
		</body>
		</html>		