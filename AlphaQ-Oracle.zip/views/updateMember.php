<?php
	require_once('../model/db.php');

	if(isset($_GET['error'])){
		echo "error received";
		echo '<br>';
		if($_GET['error'] == 'null_found'){
			echo "Invalid username or password inputed!!";
		}
	}

	$uid = "";
	if(isset($_GET['id'])){
		$uid= trim($_GET['id']);
		$sql = "select * from gym_member where member_id={$uid}";
		$conn = getConnection();
		$stmt = oci_parse($conn, $sql);
		oci_execute($stmt);
		$row = oci_fetch_assoc($stmt);
	}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Member</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
</head>
<body>
    <nav>
        <div class="container">
            <div class="row">
				<a href="profile.php">Profile</a>
				<a href="../control/logout.php">Logout</a>
			</div>
        </div>
    </nav>
    <div class="container">
        <div class="content">
            <h2>Update Member</h2>
            <a href="members.php">Back</a>

            <form method="post" action="../control/updateMemberCheck.php">
                <table>
                    <td><input type="text" name="id" value="<?=$row['MEMBER_ID']?>" hidden></td>
                    <tr>
                        <td>Name</td>
                        <td><input type="text" name="name" id="name" value="<?=$row['MEMBER_NAME']?>" required></td>
                    </tr>
                    <tr>
                        <td>Contact</td>
                        <td><input type="text" name="contact" id="contact" value="<?=$row['CONTACT']?>" required></td>
                    </tr>
                    <tr>
                        <td>Joindate</td>
                        <td><input type="date" name="joindate" id="joindate" value="<?=$row['JOIN_DATE']?>" required></td>
                    </tr>
                    <tr>
                        <td>Trainer</td>
                        <td>
                            <select name="trainer">
                                <?php
                                    $sql = "select * from gym_trainer";
                                    $stmt = oci_parse($con, $sql);
                                    oci_execute($stmt);

                                    while($row = oci_fetch_assoc($stmt)){
                                        echo "<option value=".$row['TRAINER_ID']." >".$row['TRAINER_NAME']."</option>";
                                    }
                                ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type="submit" name="update" value="Update"></td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
</body>
</html>