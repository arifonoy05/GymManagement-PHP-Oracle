<?php
	require_once('../model/db.php');

	if(isset($_GET['error'])){
		echo "error received";
		echo '<br>';
		if($_GET['error'] == 'null_found'){
			echo "Invalid username or password inputed!!";
		}
	}

	$uid = "";
	if(isset($_GET['id'])){
		$uid= trim($_GET['id']);
		$sql = "select * from gym_trainer where trainer_id={$uid}";
		$conn = getConnection();
		$stmt = oci_parse($conn, $sql);
		oci_execute($stmt);
		$row = oci_fetch_assoc($stmt);
	}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Trainer</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
</head>
<body>
    <nav>
        <div class="container">
            <div class="row">
				<a href="profile.php">Profile</a>
				<a href="../control/logout.php">Logout</a>
			</div>
        </div>
    </nav>
    <div class="container">
        <div class="content">
            <h2>Update Trainer</h2>
            <a href="trainers.php">Back</a>

            <form method="post" action="../control/updateTrainerCheck.php">
                <table>
                    <td><input type="text" name="id" id="id" value="<?=$row['TRAINER_ID']?>" hidden></td>
                    <tr>
                        <td>Name</td>
                        <td><input type="text" name="name" id="name" value="<?=$row['TRAINER_NAME']?>" required></td>
                    </tr>
                    <tr>
                        <td>Contact</td>
                        <td><input type="text" name="contact" id="contact" value="<?=$row['CONTACT']?>" required></td>
                    </tr>
                    <tr>
                        <td>Hiredate</td>
                        <td><input type="date" name="hiredate" id="hiredate" value="<?=$row['HIRE_DATE']?>" required></td>
                    </tr>
                    <tr>
                        <td>Salary</td>
                        <td><input type="number" name="salary" id="salary" value="<?=$row['SALARY']?>" required></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type="submit" name="update" value="Update"></td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
</body>
</html>