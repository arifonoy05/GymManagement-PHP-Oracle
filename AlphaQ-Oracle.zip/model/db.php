<?php
    $dbName = "SYSTEM";                  // Use your username
	$dbPass = "admin";             // and your password
	$dbURL = "localhost/oracle";   // and database URL

	function getConnection(){
		global $dbName, $dbPass, $dbURL;
		$conn = oci_connect($dbName, $dbPass, $dbURL);
		
		return $conn;
	}
	$con = getConnection();
				// create and drop table
	// $sql = "drop table gym_admin";
	// $sql = "alter table gym_member add constraint c4 foreign key (trainer_id) references gym_trainer (trainer_id)";
	// $sql = "insert into gym_admin values (1, 'admin', 'admin', 'admin', 1, 'admin@gym.com', 1)";
	// $stmt = oci_parse($con, $sql);
	// $result = oci_execute($stmt);

	// if($result){
	// 	echo "sql worked"; 					//worked, dont run again
	// }
	// else{
	// 	echo "failed";
	// }
				//create and drop sequence 
	// $sql = "drop sequence eqp_seq";
	// $sql = "create sequence eqp_seq minvalue 0 start with 0 increment by 1 cache 20";
	// $stmt = oci_parse($con, $sql);
	// $result = oci_execute($stmt);

    // if($result){
	// 	echo "sequence created"; 					//worked, dont run again
	// }
	// else{
	// 	echo "failed";
	// }
				//create and drop procedure
	// $sql = "create or replace procedure 
	// 		reg_proc(p_id in users.id%TYPE,
	// 				 p_uname in users.username%TYPE,
	// 				 p_name in users.name%TYPE,
	// 				 p_pass in users.password%TYPE,
	// 				 p_email in users.email%TYPE)
	// 				 is 
	// 				 begin
	// 				 insert into users (id, name, username, password, email)
	// 				 values (p_id, p_uname, p_name, p_pass, p_email);
	// 				 commit;
	// 				 end;";
	// $sql = "drop procedure system.reg_proc";
	// $stmt = oci_parse($con, $sql);
	// oci_execute($stmt);

	// $sql = "create or replace procedure 
	// 		admin_reg(a_id in gym_admin.id%TYPE,
	// 				 a_name in gym_admin.name%TYPE,
	// 				 a_uname in gym_admin.username%TYPE,
	// 				 a_pass in gym_admin.password%TYPE,
	// 				 a_type in gym_admin.type%TYPE,
	// 				 a_contact in gym_admin.contact%TYPE,
	// 				 a_gid in gym_admin.gym_id%type)
	// 				 is 
	// 				 begin
	// 				 insert into gym_admin (id, name, username, password, type, contact, gym_id)
	// 				 values (a_id, a_name, a_uname, a_pass, a_type, a_contact, a_gid);
	// 				 commit;
	// 				 end;";
	// $stmt = oci_parse($con, $sql);
	// oci_execute($stmt);

	// $sql = "create or replace procedure 
	// 		member_reg(m_id in gym_member.member_id%TYPE,
	// 				 m_name in gym_member.member_name%TYPE,
	// 				 m_contact in gym_member.contact%TYPE,
	// 				 m_joindate in gym_member.join_date%TYPE,
	// 				 m_tid in gym_member.trainer_id%type)
	// 				 is 
	// 				 begin
	// 				 insert into gym_member (member_id, member_name, contact, join_date, trainer_id)
	// 				 values (m_id, m_name, m_contact, to_date(m_joindate,'MM/DD/YYYY'), m_tid);
	// 				 commit;
	// 				 end;";
	// // $sql = "drop procedure member_reg";
	// $stmt = oci_parse($con, $sql);
	// oci_execute($stmt);
	//procedure for edit trainer
	// $sql = "create or replace procedure 
	// 		trainer_upd(t_id in gym_trainer.trainer_id%TYPE,
	// 		t_name in gym_trainer.trainer_name%TYPE,
	// 		t_contact in gym_trainer.contact%TYPE,
	// 		t_sal in gym_trainer.salary%TYPE)
	// 		is 
	// 		begin
	// 		update gym_trainer set trainer_name = t_name, contact = t_contact, salary = t_sal where trainer_id = t_id;
	// 		commit;
	// 		end;";
	// $sql = "drop procedure trainer_upd";
	// $stmt = oci_parse($con, $sql);
	// oci_execute($stmt);
	
	// $sql = "create or replace procedure 
	// 		eqp_upd(e_id in gym_equipment.eqp_id%TYPE,
	// 		e_name in gym_equipment.eqp_name%TYPE,
	// 		e_price in gym_equipment.eqp_price%TYPE)
	// 		is 
	// 		begin
	// 		update gym_equipment set eqp_name = e_name, eqp_price = e_price where eqp_id = e_id;
	// 		commit;
	// 		end;";
	// $stmt = oci_parse($con, $sql);
	// oci_execute($stmt);
?>